package com.example.orangestarfox.control;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.hardware.ConsumerIrManager;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * Android红外线遥控官方Demo
 *
 * @description：
 * @author ldm
 * @date 2016-4-28 下午5:06:28
 */
public class MainActivity extends Activity {
    private static final String TAG = "ConsumerIrTest";
    private TextView mFreqsText;
    // Android4.4之后 红外遥控ConsumerIrManager，可以被小米4调用
    private ConsumerIrManager mCIR;

    @SuppressLint("InlinedApi")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // 获取系统的红外遥控服务
        mCIR = (ConsumerIrManager) getSystemService(Context.CONSUMER_IR_SERVICE);
        initViewsAndEvents();
    }

    private void initViewsAndEvents() {
        findViewById(R.id.send_button).setOnClickListener(mSendClickListener);
        findViewById(R.id.get_freqs_button)
                .setOnClickListener(mOnClickListener);
        mFreqsText = (TextView) findViewById(R.id.freqs_text);
    }

    View.OnClickListener mSendClickListener = new View.OnClickListener() {
        @TargetApi(Build.VERSION_CODES.KITKAT)
        public void onClick(View v) {
            if (!mCIR.hasIrEmitter()) {
                Log.e(TAG, "未找到红外发生器！");
               return;
            }

            EditText editText=(EditText)findViewById(R.id.meaasge);
            EditText editText1=(EditText)findViewById(R.id.command);
            String str=editText.getText().toString();
            String com=editText1.getText().toString();
            char[] ch=str.toCharArray();
            double delay;
            int i,j;
            int[] pattern0=new int[32];
            int[] pattern;
            if(com.equals("sm")) {
                for (i = 0; i < ch.length; i++) {
                    pattern0 = Char2Binnary(ch[i]);
                    pattern = code(pattern0);
                    mCIR.transmit(38000, pattern);
                    for (j = 0; j < 10000; j++) ;


                }
            }
            if(com.equals("sd")) {
                try{
                    delay=Double.valueOf(editText.getText().toString());
                    if(delay<0){delay=0;}
                    if(delay>25.5){delay=25.5;}
                    int delay0=(int)(delay*10);
                    String delay1=Integer.toBinaryString(delay0);

                    delay1=format(delay1);
                    delay1=reverse(delay1);
                    for(i=0;i<8;i++){
                        if(delay1.charAt(i)=='1'){
                            delay1=delay1+'0';
                        }
                        else{
                            delay1=delay1+'1';
                        }
                    }


                    delay1=delay1+"0111111110000000";


                    for (i = 0; i < 32; i++) {
                        pattern0[i] = Integer.parseInt(String.valueOf(delay1.charAt(i)));
                    }
                    pattern=code(pattern0);

                    mCIR.transmit(38000, pattern);

                }catch(Exception e){
                    Toast.makeText(getApplicationContext() , "illegal content", Toast.LENGTH_SHORT).show();
                }

            }
            if(com.equals("sp")){
                String str1="00000000"+"11111111"+"10111111"+"01000000";
                for (i = 0; i < 32; i++) {
                    pattern0[i] = Integer.parseInt(String.valueOf(str1.charAt(i)));
                }
                pattern=code(pattern0);
                mCIR.transmit(38000, pattern);

            }
        }
    };

    @SuppressLint("NewApi")
    View.OnClickListener mOnClickListener = new View.OnClickListener() {
        public void onClick(View v) {
            StringBuilder b = new StringBuilder();

            if (!mCIR.hasIrEmitter()) {
                mFreqsText.setText("未找到红外发生器！");
                return;
            }

            // 获得可用的载波频率范围
           ConsumerIrManager.CarrierFrequencyRange[] freqs = mCIR
                    .getCarrierFrequencies();
            b.append("IR Carrier Frequencies:\n");// 红外载波频率
            // 边里获取频率段
            for (ConsumerIrManager.CarrierFrequencyRange range : freqs) {
                b.append(String.format("    %d - %d\n",
                        range.getMinFrequency(), range.getMaxFrequency()));
            }
            mFreqsText.setText(b.toString());// 显示结果
        }
    };
    public int[] code(int[] x){
        int len=x.length;
        int i;
        int[] C=new int[2*len+2];
        C[0]=9000;
        C[1]=4500;
        for(i=0;i<len;i++){
            if(x[i]==0){
                C[i*2+2]=560;
                C[i*2+3]=560;
            }
            else{
                C[i*2+2]=560;
                C[i*2+3]=1680;
            }
        }
        return C;
    }
    public int[] Char2Binnary(char ch) {

        int[] code = new int[32];
        String str;
        int i;
        String dic=getResources().getString(R.string.dictionary);
        char[] chars=dic.toCharArray();
        for(i=0;i<chars.length;i++){
            if(chars[i]==ch){
                break;
            }
        }
        //1111
        String binaryString = Integer.toBinaryString(i);
        str=format(binaryString);
        str=reverse(str);
        for(i=0;i<8;i++){
            if(str.charAt(i)=='1'){
                str=str+'0';
            }
            else{
                str=str+'1';
            }
        }


            str=str+"1111111100000000";
        for (i = 0; i < code.length; i++) {
            code[i] = Integer.parseInt(String.valueOf(str.charAt(i)));
        }
        return code;
    }
public String format(String str){
    int i;
    for( i=0;i<8;i++) {
        if (str.length() < 8) {
            str = '0'+str ;
        }
    }
        return  str;
    }
public  String reverse(String str){
    char[] rts=new char[8];
    int i;
    for(i=0;i<8;i++){
        rts[i]=str.charAt(7-i);
    }
    str = String.valueOf(rts);
    return str;

}

}

